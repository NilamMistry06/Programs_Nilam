﻿namespace Practical_Nilam
{
    public class Candidate
    {
        public string name { get; set; }
        public string phone { get; set; }
    }
}
